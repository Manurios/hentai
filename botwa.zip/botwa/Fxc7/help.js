const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `
	
\`\`\`Follow My Instagram\`\`\`
${instagram}

\`\`\`SUBSCRIBE😁\`\`\`
${yt}

\`\`\`GROUP OFFICIAL\`\`\`
https://chat.whatsapp.com/GHC5djoQJrcGBJFwYQuQoB


\`\`\`HARAP BACA NOTE DIBAWAH SEBELUM\`\`\`
\`\`\`MENGGUNAKAN BOT\`\`\`

╭──────「 *REGULATION ${name}* 」
┴
┣⊱  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIVICATION:\`\`\` ✅
┣⊱  \`\`\`LIMIT:\`\`\` *${limitt}*
┣⊱  \`\`\`AKTIF:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`JAM:\`\`\` *${jam} WIB*
┣⊱  \`\`\`TANGGAL:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSION:\`\`\` *6.5.0*
┣⊱  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┣⊱  ❌ *SPAM*
┣⊱  ❌ *CALL & VC*
┣⊱  \`\`\`Melanggar??\`\`\` *Banned*
┬
╰────────────────────────


╭──────「 *ABOUT ${name}* 」
┴
│➻ *${prefix}report lapor bug*
│➻ *${prefix}info*
│➻ *${prefix}donasi*
│➻ *${prefix}owner*
│➻ *${prefix}speed*
│➻ *${prefix}daftar*
│➻ *${prefix}totaluser*
│➻ *${prefix}grouplist*
│➻ *${prefix}blocklist*
│➻ *${prefix}banlist*
│➻ *${prefix}premiumlist*
│➻ *${prefix}bahasa*
┬
╰────────────────────────


͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *MEDIA DOWNLOADER* 」
┴
│➻ *${prefix}tiktokstalk username*
│➻ *${prefix}igstalk _farhan_xcode7*
│➻ *${prefix}insta Link*
│➻ *${prefix}instastory username*
│➻ *${prefix}ssweb url*
│➻ *${prefix}url2img Url*
│➻ *${prefix}tiktok*
│➻ *${prefix}fototiktok*
│➻ *${prefix}meme*
│➻ *${prefix}memeindo*
│➻ *${prefix}kbbi*
│➻ *${prefix}wait*
│➻ *${prefix}trendtwit*
│➻ *${prefix}google berita terkini*
┬
╰────────────────────────


╭──────「 *CREATOR MENU* 」
┴
│➻ *${prefix}quotemaker tx/wtrmk/tema*
│➻ *${prefix}nulis nama/kelas/text*
│➻ *${prefix}rain reply image*
│➻ *${prefix}trigger reply image*
│➻ *${prefix}rip reply image*
│➻ *${prefix}wasted reply image*
│➻ *${prefix}cphlogo FXC7/BOT*
│➻ *${prefix}cglitch FXC7/BOT*
│➻ *${prefix}cpubg FXC7/BOT*
│➻ *${prefix}cml FXC7*
│
│➻ *${prefix}tahta FXC7*
│➻ *${prefix}croman FXC7 dan BOT*
│➻ *${prefix}cthunder FXC7*
│➻ *${prefix}cbpink FXC7*
│➻ *${prefix}cmwolf FXC7*
│➻ *${prefix}csky FXC7*
│➻ *${prefix}cwooden FXC7*
│➻ *${prefix}cflower FXC7*
│➻ *${prefix}clove FXC7*
│➻ *${prefix}ccrossfire FXC7*
│➻ *${prefix}cnaruto FXC7*
│➻ *${prefix}cparty FXC7*
│➻ *${prefix}cshadow FXC7*
│➻ *${prefix}cminion FXC7*
│➻ *${prefix}cneon FXC7*
│➻ *${prefix}cneon2 FXC7*
│➻ *${prefix}cneongreen FXC7*
│➻ *${prefix}c3d FXC7*
│➻ *${prefix}csky FXC7*
│➻ *${prefix}tts id Haii*
│➻ *${prefix}ttp Fxc7*
│➻ *${prefix}cballon Fxc7*
│➻ *${prefix}cpaper Fxc7*
│➻ *${prefix}slide Fxc7 BOT WA*
│
│➻ *${prefix}stiker*
│➻ *${prefix}gifstiker*
│➻ *${prefix}toimg*
│➻ *${prefix}img2url*
│➻ *${prefix}nobg*
│➻ *${prefix}tomp3*
│➻ *${prefix}ocr*
┬
╰──────────────────────────


╭───────「 *GROUP ONLY* 」
┴
│➻ *${prefix}modeanime On/Off*
│➻ *${prefix}naruto*
│➻ *${prefix}minato*
│➻ *${prefix}boruto*
│➻ *${prefix}hinata*
│➻ *${prefix}sakura*
│➻ *${prefix}sasuke*
│➻ *${prefix}kaneki*
│➻ *${prefix}toukachan*
│➻ *${prefix}rize*
│➻ *${prefix}akira*
│➻ *${prefix}itori*
│➻ *${prefix}kurumi*
│➻ *${prefix}miku*
│➻ *${prefix}anime*
│➻ *${prefix}animecry*
│➻ *${prefix}neonime*
│➻ *${prefix}animekiss*
│➻ *${prefix}wink*
┬
╰───────────────────────

╭────────────────────────
┴
│➻ *${prefix}welcome On/Off*
│➻ *${prefix}grup buka/tutup*
│➻ *${prefix}antilink on/off*
│➻ *${prefix}ownergrup*
│➻ *${prefix}setpp*
│➻ *${prefix}infogc*
│➻ *${prefix}add*
│➻ *${prefix}kick*
│➻ *${prefix}promote*
│➻ *${prefix}demote*
│➻ *${prefix}setname*
│➻ *${prefix}setdesc*
│➻ *${prefix}linkgrup*
│➻ *${prefix}tagme*
│➻ *${prefix}hidetag*
│➻ *${prefix}tagall*
│➻ *${prefix}mentionall*
│➻ *${prefix}fitnah*
│➻ *${prefix}listadmin*
│➻ *${prefix}openanime*
│➻ *${prefix}edotense*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}nsfw On/Off*
│➻ *${prefix}nsfwloli*
│➻ *${prefix}nsfwblowjob*
│➻ *${prefix}nsfwneko*
│➻ *${prefix}nsfwtrap*
│➻ *${prefix}hentai*
│➻ *${prefix}simih On/Off*
┬
╰────────────────────────


╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}anjing*
│➻ *${prefix}kucing*
│➻ *${prefix}testime*
│➻ *${prefix}hilih*
│➻ *${prefix}say*
│➻ *${prefix}apakah*
│➻ *${prefix}kapankah*
│➻ *${prefix}bisakah*
│➻ *${prefix}rate*
│➻ *${prefix}watak*
│➻ *${prefix}hobby*
│➻ *${prefix}infogempa*
│➻ *${prefix}infonomor*
│➻ *${prefix}quotes*
│➻ *${prefix}truth*
│➻ *${prefix}dare*
│➻ *${prefix}katabijak*
│➻ *${prefix}fakta*
│➻ *${prefix}darkjokes*
│➻ *${prefix}bucin*
│➻ *${prefix}pantun*
│➻ *${prefix}katacinta*
│➻ *${prefix}jadwaltvnow*
│➻ *${prefix}hekerbucin*
│➻ *${prefix}katailham*
│➻ *${prefix}animewp*
┬
╰────────────────────────

╭──────────────────────────
┴
│➻ *${prefix}jarak Banyuwangi/Surabaya*
│➻ *${prefix}translate en/Apa kabar?*
│➻ *${prefix}pasangan Farhan/Iriene*
│➻ *${prefix}gantengcek Farhan*
│➻ *${prefix}cantikcek Iriene*
│➻ *${prefix}artinama Farhan*
│➻ *${prefix}persengay Topan*
│➻ *${prefix}pbucin Farhan*
│➻ *${prefix}bpfont Farhan*
│➻ *${prefix}textstyle FXC7*
│➻ *${prefix}jadwaltv antv*
│➻ *${prefix}lirik melukis senja*
│➻ *${prefix}chord Melukis senja*
│➻ *${prefix}wiki Adolf Hitler*
│➻ *${prefix}brainly pertanyaan*
│➻ *${prefix}resepmasakan rawon*
│➻ *${prefix}map Banyuwangi*
│➻ *${prefix}film Fast and Farious*
│➻ *${prefix}pinterest gambar kucing*
│➻ *${prefix}infocuaca Banyuwangi*
│➻ *${prefix}jamdunia Banyuwangi*
│➻ *${prefix}mimpi Ular*
│➻ *${prefix}infoalamat jalan Banyuwangi*
│➻ *${prefix}playstore WhatsApp*
┬
╰───────────────────────────


╭────────────────────────
┴
│➻ *${prefix}asupan*
│➻ *${prefix}tebakgambar*
│➻ *${prefix}caklontong*
│➻ *${prefix}family100*
│➻ *${prefix}kalkulator 13*12*
│➻ *${prefix}wp gunung*
│➻ *${prefix}moddroid lightroom*
│➻ *${prefix}happymod lightroom*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}cerpen*
│➻ *${prefix}cersex*
│➻ *${prefix}xxx japan*
│➻ *${prefix}pornhub stepMoms*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}jadwalsholat Banyuwangi*
│➻ *${prefix}quran*
│➻ *${prefix}quransurah 1*
│➻ *${prefix}tafsir kafir*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}becrypt string*
│➻ *${prefix}encode64 string*
│➻ *${prefix}decode64 encrypt*
│➻ *${prefix}encode32 string*
│➻ *${prefix}decode32 encrypt*
│➻ *${prefix}encbinary string*
│➻ *${prefix}decbinary encrypt*
│➻ *${prefix}encoctal string*
│➻ *${prefix}decoctal encrypt*
│➻ *${prefix}hashidentifier Encrypt Hash*
│➻ *${prefix}dorking dork*
│➻ *${prefix}pastebin teks*
│➻ *${prefix}tinyurl link*
│➻ *${prefix}bitly link*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}spamcall 083xxxxxxxxx*
│➻ *${prefix}spamsms 083xxxxxxxx/jumlah*
│➻ *${prefix}spamgmail farhanxcode7@gmail.com*
┬
╰────────────────────────


╭─────────「 *OWNER ONLY* 」
┴
│➻ *${prefix}addprem mentioned*
│➻ *${prefix}removeprem mention*
│➻ *${prefix}setmemlimit*
│➻ *${prefix}setreply*
│➻ *${prefix}setprefix*
│➻ *${prefix}setnamebot*
│➻ *${prefix}setppbot*
│➻ *${prefix}bc*
│➻ *${prefix}bcgc*
│➻ *${prefix}ban*
│➻ *${prefix}unban*
│➻ *${prefix}block*
│➻ *${prefix}unblock*
│➻ *${prefix}clearall*
│➻ *${prefix}delete*
│➻ *${prefix}clone*
│➻ *${prefix}getses*
│➻ *${prefix}leave*
┬
╰────────────────────────


╭────────「 *PREMIUM ONLY* 」
┴
│➻ *${prefix}playmp3 menepi*
│➻ *${prefix}fb link video*
│➻ *${prefix}snack link snack video*
│➻ *${prefix}ytmp3 link yt*
│➻ *${prefix}ytmp4 link yt*
│➻ *${prefix}joox Monolog Pamungkas*
│➻ *${prefix}smule Link Video Smule*
┬
╰────────────────────────


╭─────「 *SUPPORT ${name}* 」
│
├➲ *O BOT*
├➲ *M. HADI FIRMANSYA*
├➲ *DELIA AULIA*
├➲ *KEVIN DAVID*
├➲ *MY TEAM FXC7 BOT*
╰────────────────────────`
}

exports.help = help

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}
