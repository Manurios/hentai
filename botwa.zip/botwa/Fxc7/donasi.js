const donasi = (name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DONASI SEIKHLASNYA:)* ❉⊰━━✿
┃  
┣━⊱ *OVO*
┣⊱ 08311800241
┣━⊱ *PULSA*
┣⊱ 08311800241
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ${name}*
┗━━━━━━━━━━━━━━━━━━━━

`
}
exports.donasi = donasi