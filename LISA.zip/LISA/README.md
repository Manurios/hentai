### I'm FXC7BOT Gift Me Stars 🌟 <br><img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="20px">
<p align="center">
<a href="https://github.com/Fxc7"><img src="https://raw.githubusercontent.com/Fxc7/termux-bot-wa/main/src/glitchtext.png"></a>
</p>
<br>



<p align="center">
<a href="#"><img title="termux-bot-wa" src="https://img.shields.io/badge/-TERMUX--BOT--WA-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Fxc7"><img title="Author" src="https://img.shields.io/badge/AUTHOR-FARHAN-orange?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Fxc7/termux-bot-wa/followers"><img title="Followers" src="https://img.shields.io/github/followers/Fxc7?style=flat-square"></a>
<a href="https://github.com/Fxc7/termux-bot-wa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Fxc7/termux-bot-wa?style=flat-square"></a>
<a href="https://github.com/Fxc7/termux-bot-wa/watchers"><img title="watchers" src="https://img.shields.io/github/watchers/FarhanXCode7/termux-bot-wa?style=flat-square"></a>

</p>


<details>



* [Gopay](083141926935)
* [Pulsa](083141926935)
</details>

## Tools

```bash
> Termux
> WhatsApp
> 2 HandPhone
```

## Install
Follow The Steps Below!

```bash
> termux-setup-storage
(after that tap on permission)
> pkg update -y
> pkg upgrade -y
> pkg install git -y
> git clone https://github.com/Fxc7/termux-bot-wa
> cd termux-bot-wa
> npm cache clear
> bash install.sh
> npm audit fix
> npm start / node index.js
```

<p align="center">
<a href="#"><img title="termux-bot-wa" src="https://img.shields.io/badge/-TAMPILAN--MENU-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>

<img src="https://raw.githubusercontent.com/Fxc7/termux-bot-wa/main/src/Screenshot_2021-01-29-18-18-32-18.jpg" width="100px" height="150px">

## Features

| NEW USER | YES
| :---------------------------------------------: | :-----------: |
|  Register Name And Age origin|✅|

|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Black Pink Logo Maker|✅|
| 3D Text Maker|✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker
| Marvel Logo Maker|✅|
| Snow Write Maker|✅|
| Ninja Logo Maker|✅|
| Logo Wolf Maker|✅|
| And much more |✅|

| MEDIA | YES |
| :-----------------: | :-------: |
| Trend Twit|✅|
| YT Search|✅|
| Wattpad Search|✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| The Meaning Of The Name|✅|
| Text To Sticker|✅|
| Nulis Name/class/text|✅|
| Quotes|✅|

| ASK | YES |
| :-----------------: | :-------: |
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|

| DOWNLOADER | YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| Text To Speach|✅|

| MUSIC | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|
| Qur'an Surah 1,2,3 dll |✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| WIBU | YES |
| :-----------------: | :-------: |
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Naruto|✅|
| Loli|✅|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| And much more|✅|

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| Glitch|✅|
| hilih|✅|
| Cek Ganteng|✅|
| Watak|✅|
| Random Hobby|✅|
| Pinterest [Optional] |✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|
| Gempa Terkini|✅|

| 18+ | YES |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Set pp bot|✅|
| Set Reply Chat|✅|
| add premium |✅|
| remove premium |✅|
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|

| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Youtube mp3 Download|✅|
| Youtube mp4 Download|✅|
| Joox|✅|
| Facebook Video Download|✅|
| Snack Video Download|✅|
| Play Mp3|✅|

 TENTANG BOT | YES |
| :-----------------: | :-------: |
| info|✅|
| ChatList|❌|


## Note

* Dont Forget Stars

* |En| And You can add your own quotes
* |Ind| Dan Kalian Bisa tambahkan Quotes Kalian


## Special Thanks

* [Baileys](https://github.com/adiwajshing/baileys)
* Created Bot => [MhankBarBar](https://github.com/MhankBarBar)
* [NURUTOMO](https://github.com/nurutomo)



## Group

* <a href="https://chat.whatsapp.com/GHC5djoQJrcGBJFwYQuQoB"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---
