const snk = () => { 
	return `Syarat dan Ketentuan Bot *XPTN* 
1. Kami tidak menyimpan gambar, video, file, audio, dan dokumen yang anda kirim
2. Kami tidak akan pernah meminta anda untuk memberikan informasi pribadi
3. Jika menemukan Bug/Error silahkan langsung lapor ke Owner bot
4. Apapun yang anda perintah pada bot ini, KAMI TIDAK AKAN BERTANGGUNG JAWAB!

Thanks !`
}
exports.snk = snk