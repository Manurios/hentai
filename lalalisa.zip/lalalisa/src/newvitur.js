const newvitur = (prefix) => { 
	return `
╔══✪〘 UPDATE 〙✪══
║
║
╠➥ *${prefix}happymod <nama apk>*
╠➥ *${prefix}modroid <nama apk>*
╠➥ *${prefix}play2 <nama lagu>*
║
╚═〘 XPTN BOT 〙`
}
exports.newvitur = newvitur