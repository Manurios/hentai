const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6289655478810 atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP BOT :*
_https://chat.whatsapp.com/DiqQCtQ1FPSJsC7lr8bqwO_ `
}
exports.daftarvip = daftarvip