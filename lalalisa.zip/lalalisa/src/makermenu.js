const makermenu = (prefix) => { 
	return `
╔══✪〘 MAKER 〙✪══
║
╠➥ *${prefix}tahta* [iki]
╠➥ *${prefix}pronlogo* [text|text]
╠➥ *${prefix}bpink [teks]* 
╠➥ *${prefix}snow* [text|text] 
╠➥ *${prefix}marvelogo* [text|text] 
╠➥ *${prefix}text3d* [text] 
╠➥ *${prefix}ninjalogo* [text|text] 
╠➥ *${prefix}wolflogo* [text|text] 
╠➥ *${prefix}lionlogo* [text|text] 
╠➥ *${prefix}textscreen* [text
╠➥ *${prefix}rtext* [text]
╠➥ *${prefix}thunder* [text] [
╠➥ *${prefix}glaas*
╠➥ *${prefix}triggerd*
╠➥ *${prefix}burning*
╠➥ *${prefix}pelangi*
╠➥ *${prefix}stiltext* [text|text]
╠➥ *${prefix}party* [text]
╠➥ *${prefix}galaxtext* [text]
╠➥ *${prefix}lovemake* [text]
╠➥ *${prefix}walpaperhd* [text]
╠➥ *${prefix}watercolor* [text]
╠➥ *${prefix}quotemaker* [tx|tx|random] 
╠➥ *${prefix}water* [text]
╠➥ *${prefix}epep* [text]
╠➥ *${prefix}glitch* [text]
╠➥ *${prefix}jokerlogo [teks]* 
║
╚═〘 Lalalisa BOT 〙`
}
exports.makermenu = makermenu