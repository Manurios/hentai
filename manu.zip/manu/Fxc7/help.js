// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `
\`\`\`FOLLOW OWNER INSTAGRAM\`\`\`
\`\`\` ${instagram}\`\`\`
	
\`\`\`HARAP BACA NOTE DIBAWAH SEBELUM\`\`\`
\`\`\`MENGGUNAKAN BOT\`\`\`

     \`\`\`RULES - SIMPLE\`\`\`
      ▬●▬●▬●▬●▬●▬●▬
 °❀ *Spam : Auto Block!*
 °❀ *Beri Jeda 5detik Saat Menggunakannya!!*
 °❀ *Bug/Error Harap Cht Owner!*
 °❀ *Untuk Memastikan Bot Off Atau On*
 °❀ *Harap Sabar Dengan Bug²nya!*
 
╭──────「 *REGULATION ${name}* 」
┴
┃❀°\`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°\`\`\`VERIVICATION:\`\`\` ✅
┃❀°\`\`\`LIMIT:\`\`\` *${limitt} perhari*
┃❀°\`\`\`AKTIF:\`\`\` ${kyun(uptime)}
┃❀°\`\`\`JAM:\`\`\` *${jam} WIB*
┃❀°\`\`\`TANGGAL:\`\`\` *${tanggal}*
┃❀°\`\`\`VERSION:\`\`\` *6.5.0*
┃❀°\`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┃❀° \`\`\`DONASI:\`\`\` *1%*
┃❀°❌ \`\`\`SPAM\`\`\`
┃❀°❌ \`\`\`CALL & VC\`\`\`
┃❀°\`\`\`Melanggar??\`\`\` *Banned + Out Group*
┬
╰────────────────────────
╭────────「 *ABOUT ${name}* 」
┴
│➻ ${prefix}report *Untuk Lapor Bug*
│➻ ${prefix}info *Untuk Mengetahui Info*
│➻ ${prefix}donasi *Untuk Donasi*
│➻ ${prefix}owner *Untuk Mengetahui Owner*
│➻ ${prefix}speed *Untuk Test Jaringan Bot*
│➻ ${prefix}profile *Mengirim Profil*
│➻ ${prefix}daftar *Untuk Mendaftar ke Database*
│➻ ${prefix}limit *Untuk Cek Limit*
│➻ ${prefix}totaluser *Melihat User*
│➻ ${prefix}blocklist *Melihat Nomor Yang diBlok*
│➻ ${prefix}banlist *Melihat Nomor Yang diBan*
│➻ ${prefix}premiumlist *Melihat Nomor Yang Prem*
┬
╰────────────────────────
͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *DOWNLOADER* 」
┴
│➻ ${prefix}instavid *Link Valid*
│➻ ${prefix}instaimg *Link Valid*
│➻ ${prefix}instastory *Username*
│➻ ${prefix}ssweb *Url*
│➻ ${prefix}url2img *Url*
│➻ ${prefix}tiktok *Random Tiktok*
│➻ ${prefix}fototiktok *Random Tiktok*
│➻ ${prefix}wait *Cari Film Anime with Reply*
┬
╰────────────────────────
͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *SEARCH* 」
┴
│➻ ${prefix}jadwaltvnow *Channel Tv*
│➻ ${prefix}trendtwit *Untuk Melihat Trend di Twitter*
│➻ ${prefix}google berita terkini *Berita Terkini*
│➻ ${prefix}kbbi *Kamus Besar Bahasa Indonesia*
│➻ ${prefix}bahasa *Untuk Melihat Kode Bahasa*
│➻ ${prefix}infogempa *Wilayah Terkena Gempa*
│➻ ${prefix}infonomor *Nomor*
│➻ ${prefix}infoalamat jalan *Kota*
├───────────────────
│➻ ${prefix}lirik *Lagu*
│➻ ${prefix}chord *Lagu*
│➻ ${prefix}wiki *Pertanyaan*
│➻ ${prefix}brainly *Pertanyaan*
│➻ ${prefix}resepmasakan *Masakan*
│➻ ${prefix}map *Kota*
├───────────────────
│➻ ${prefix}film *Film*
│➻ ${prefix}pinterest *Gambar Yang Ingin Dicari*
│➻ ${prefix}infocuaca *Kota*
│➻ ${prefix}jamdunia *Kota*
│➻ ${prefix}jarak *Kota1/Kota2*
│➻ ${prefix}translate *en/Apa kabar?*
│➻ ${prefix}playstore *Apk Yang Ingin Dicari*
│➻ ${prefix}ytsearch *Apa Yang Ingin Dicari*
│➻ ${prefix}moddroid *ApkMod Yang ingin Dicari*
│➻ ${prefix}happymod *ApkMod Yang ingin Dicari*
│➻ ${prefix}kalkulator *Angka*
┬
╰────────────────────────
͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *STALK* 」
┴
│➻ ${prefix}igstalk *manuuuriosss_*
│➻ ${prefix}tiktokstalk *Username*
│➻ ${prefix}instastory *Username*
┬
╰────────────────────────
╭──────「 *KERANG AJAIB* 」
┴

│➻ ${prefix}pasangan *@mentioned/@mentioned*
│➻ ${prefix}gantengcek *@mentioned*
│➻ ${prefix}cantikcek *@mentioned*
│➻ ${prefix}persengay *@mentioned*
│➻ ${prefix}pbucin *@mentioned*
├───────────────────
│➻ ${prefix}artinama *Nama*
│➻ ${prefix}apakah *Pertanyaan*
│➻ ${prefix}kapankah *Pertanyaan*
│➻ ${prefix}bisakah *Pertanyaan*
├───────────────────
│➻ ${prefix}rate *@mentioned*
│➻ ${prefix}watak *@mentioned*
│➻ ${prefix}hobby *@mentioned*
┬
╰──────────────────────────
╭──────「 *MAKER* 」
┴
│➻ ${prefix}quotemaker *Tx/Wtrmk/Tema*
│➻ ${prefix}nulis *Nama/Kelas/Text*
│➻ ${prefix}croman *Text*
│➻ ${prefix}slide *Text*
├───────────────────
│➻ ${prefix}tp *1-162*
│➻ ${prefix}ep *1-216*
│➻ ${prefix}tahta *Text*
│➻ ${prefix}cglass *Text*
│➻ ${prefix}cstyle *Text*
│➻ ${prefix}cgame *Text*
│➻ ${prefix}clove *Text*
│➻ ${prefix}cparty *Text*
│➻ ${prefix}csky *Text*
│➻ ${prefix}cpaper *Text*
│➻ ${prefix}tts id *Text*
│➻ ${prefix}ttp *Error*
│➻ ${prefix}bpfont *Text*
│➻ ${prefix}textstyle *Text*
├───────────────────
│➻ ${prefix}stiker *Error*
│➻ ${prefix}gifstiker *Error*
│➻ ${prefix}trigger *Error*
│➻ ${prefix}toimg *ReplyStiker*
│➻ ${prefix}img2url *ReplyImage*
│➻ ${prefix}tomp3 *ReplyVid*
│➻ ${prefix}ocr *ReplyStiker*
┬
╰──────────────────────────
╭──────「 *ISLAM* 」
┴
│➻ ${prefix}jadwalsholat *Kota*
│➻ ${prefix}quran
│➻ ${prefix}quranlist
│➻ ${prefix}quransurah *Surah*
┬
╰────────────────────────
╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ ${prefix}tebakgambar
│➻ ${prefix}caklontong
│➻ ${prefix}family100
│➻ ${prefix}truth
│➻ ${prefix}dare
│➻ ${prefix}simih *On/Off*
│➻ ${prefix}anjing
│➻ ${prefix}kucing
│➻ ${prefix}hilih *Text*
│➻ ${prefix}fitnah *@mentioned/isi/balasan*
┬
╰────────────────────────
╭──────「 *MEME* 」
┴
│➻ ${prefix}memeindo
│➻ ${prefix}drakjokes
│➻ ${prefix}randomKPOP
┬
╰────────────────────────
╭──────「 *QUOTE* 」
┴
│➻ ${prefix}bucin
│➻ ${prefix}quotes
│➻ ${prefix}pantun
│➻ ${prefix}katacinta
│➻ ${prefix}katailham
│➻ ${prefix}katabijak
│➻ ${prefix}hekerbucin
│➻ ${prefix}fakta
│➻ ${prefix}puisiimg
┬
╰────────────────────────
╭───────「 * 18+ * 」
┴
│➻ ${prefix}nsfw *On/Off*
│➻ ${prefix}nsfwloli
│➻ ${prefix}nsfwblowjob
│➻ ${prefix}nsfwneko
│➻ ${prefix}nsfwtrap
│➻ ${prefix}hentai
├───────────────────
│➻ ${prefix}cersex
│➻ ${prefix}randombokep
│➻ ${prefix}pornhub *stepMoms*
│➻ ${prefix}xvideos *japan*
│➻ ${prefix}nekopoi *oni chichi*
│➻ ${prefix}asupan
┬
╰────────────────────────
╭──────「 *PRANK* 」
┴
│➻ ${prefix}spamcall *083xxxxxxxxx*
│➻ ${prefix}spamgmail *contoh@gmail.com*
┬
╰────────────────────────
╭──────「 *FIND ME SIR* 」
┴
│➻ ${prefix}becrypt *string*
│➻ ${prefix}encode64 *string*
│➻ ${prefix}decode64 *encrypt*
│➻ ${prefix}encode32 *string*
│➻ ${prefix}decode32 *encrypt*
│➻ ${prefix}encbinary *string*
│➻ ${prefix}decbinary *encrypt*
│➻ ${prefix}encoctal *string*
│➻ ${prefix}decoctal *encrypt*
│➻ ${prefix}hashidentifier *Encrypt Hash*
│➻ ${prefix}dorking *dork*
│➻ ${prefix}pastebin *Teks*
│➻ ${prefix}tinyurl *Link*
│➻ ${prefix}bitly *Link*
┬
╰────────────────────────
╭───────「 *ANIME* 」
┴
│➻ ${prefix}modeanime *On/Off*
│➻ ${prefix}neonime naruto
│➻ ${prefix}naruto
│➻ ${prefix}minato
│➻ ${prefix}boruto
│➻ ${prefix}hinata
│➻ ${prefix}sakura
│➻ ${prefix}sasuke
│➻ ${prefix}toukachan
│➻ ${prefix}rize
│➻ ${prefix}akira
│➻ ${prefix}itori
│➻ ${prefix}kurumi
│➻ ${prefix}miku
│➻ ${prefix}anime
│➻ ${prefix}animecry
│➻ ${prefix}animekiss
┬
╰───────────────────────
╭───────「 *GROUP ONLY* 」
┴
│➻ ${prefix}welcome *On/Off*
│➻ ${prefix}grup *buka/tutup*
│➻ ${prefix}ownergrup
│➻ ${prefix}setpp *ReplyImg*
│➻ ${prefix}infogc
│➻ ${prefix}add *628xxxxxxxxxx*
│➻ ${prefix}kick *@mentioned*
│➻ ${prefix}kicktime *@mentioned*
│➻ ${prefix}promote *@mentioned*
│➻ ${prefix}demote *@mentioned*
│➻ ${prefix}setname *Text*
│➻ ${prefix}setdesc *Text*
│➻ ${prefix}linkgrup
│➻ ${prefix}tagme
│➻ ${prefix}hidetag
│➻ ${prefix}tagall
│➻ ${prefix}mentionall
│➻ ${prefix}listadmin
┬
╰────────────────────────
╭────────「 *PREMIUM ONLY* 」
┴
│➻ ${prefix}playmp3 *Song*
│➻ ${prefix}fb *Url*
│➻ ${prefix}snack *Url*
│➻ ${prefix}ytmp3 *Url*
│➻ ${prefix}ytmp4 *Url*
│➻ ${prefix}joox *Song/Singer*
│➻ ${prefix}smule *Url*
┬
╰────────────────────────
╭─────────「 *OWNER ONLY* 」
┴
│➻ ${prefix}addprem *@mentioned*
│➻ ${prefix}removeprem *@mentioned*
│➻ ${prefix}public *enable/disable*
│➻ ${prefix}setmemlimit
│➻ ${prefix}setlimit
│➻ ${prefix}setreply
│➻ ${prefix}setprefix
│➻ ${prefix}setnamebot
│➻ ${prefix}setppbot
│➻ ${prefix}bc
│➻ ${prefix}bcgc
│➻ ${prefix}ban
│➻ ${prefix}unban
│➻ ${prefix}block
│➻ ${prefix}unblock
│➻ ${prefix}clearall
│➻ ${prefix}delete
│➻ ${prefix}clone
│➻ ${prefix}getses
│➻ ${prefix}leave
┬
╰────────────────────────
╭─────「 *SOSMED* 」
┴
│  *Ada masalah? Hub :*
│ _http://wa.me/6283141926935_
│ *Instagram* :*@manuuuriosss_*
├──────────────────
│Bot ini belum selesai sepenuhnya
│Masih dalam proses pengerjaan
│Jadi masih jarang aktif.
┬
╰────────────────────────
╭─────「 *SUPPORT ${name}* 」
┴
│➲ *FXC7*
│➲ *MHANKBARBAR*
│➲ *PENYEDIA APIKEY*
│➲ *MANURIOS*
│➲ *MY TEAM FXC7 BOT*
│➲ *CONTENT CREATOR BOT WHATSAPP*
┬
╰────────────────────────`
}


exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// info bot 
const bottt = (prefix) => {
return `
\`\`\`Untuk Sekarang Bot Hanya Bisa Digunakan Di Group Karna\`\`\` *KUOTA MAHAL*\n\n *Mohon Pengertiannya*
Sekali Lagi Maaf

Jika Bot Ini Ada Di Grup Anda,Admin Grup Aktifkan Bot Dengan Cara ${prefix}bott aktif
`
}
exports.bottt = bottt
// donasi menu
const donasi = (name) => { 
	return `       
	Mau donasi ya kak ✨
 اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّبةٍ
“jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016]_
═══════════════════
╭─────「 *DONASI SEIKHLASNYA* 」
┴
│√ *PULSA: 083141926935*
│√ *SHOPEEPAY : 083141926935*
│*Sesekali Gitu Bantu Lisa*😙
┬
╰──────「 *BY ${name}* 」

Untuk Kelangsungan Hidup Bot Karna Kuota Mahal:'
`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*maaf ${pushname2} limit hari ini habis*\n*limit di reset setiap jam 12:00 WIB TENGAH MALAM*`
}

const limitcount = (limitCounts) => {
        return`
Limit Kamu: ${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount